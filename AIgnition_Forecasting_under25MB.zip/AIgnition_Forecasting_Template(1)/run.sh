#!/usr/bin/env bash
set -euo pipefail

DATA_DIR="${1:-./data}"
MODEL_PATH="${2:-./pickle/model.pkl}"
OUTPUT_PATH="${3:-./output/predictions.csv}"

mkdir -p "$(dirname "$OUTPUT_PATH")"

# 1. Clean dynamic evaluator directory data
python3 src/generate_features.py --data-dir "$DATA_DIR" --out features.csv

# 2. Extract ranges out to submission folder path
python3 src/predict.py --features features.csv --model "$MODEL_PATH" --output "$OUTPUT_PATH"