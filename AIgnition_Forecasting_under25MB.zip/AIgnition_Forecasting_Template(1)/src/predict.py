import argparse
import pandas as pd
import joblib
from pathlib import Path

def evaluate_causal_signals(row):
    med_roas = row["roas_expected"]
    lower_rev = row["revenue_lower"]
    upper_rev = row["revenue_upper"]
    spread = (upper_rev - lower_rev) / row["revenue_expected"] if row["revenue_expected"] > 0 else 0
    
    if med_roas >= 4.0:
        insight = "PROPULSION VECTOR: High efficiency system trajectory. Positive incremental marginal returns scaling intently."
        risk = "Low Risk. Keep watch for natural audience burnout signals."
    elif med_roas >= 2.0:
        insight = "STABLE GROWING PACE: Ad parameters running inside safe attribution control limits."
        risk = "Moderate Risk. Monitor macro shifts in platform inventory CPM/CPC costs."
    else:
        insight = "STRUCTURAL EFFICIENCY DECAY: Inventory costs outpacing volume velocity. Scaling down suggested."
        risk = "High Risk. Tracking pixel anomalies or heavy creative market saturation detected."
        
    if spread > 0.55:
        risk += " Alert: Broad uncertainty variance interval highlights underlying instability metrics."
        
    return insight, risk

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--features', required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()

    df_features = pd.read_csv(args.features)
    X = df_features[["spend", "clicks", "impressions", "conversions"]]

    if not Path(args.model).exists():
        raise FileNotFoundError(f"Evaluation pipeline failure: Model artifact missing at {args.model}")

    model_bundle = joblib.load(args.model)

    output_df = pd.DataFrame({
        "revenue_lower": model_bundle["revenue_p10"].predict(X),
        "revenue_expected": model_bundle["revenue_p50"].predict(X),
        "revenue_upper": model_bundle["revenue_p90"].predict(X),
        "roas_lower": model_bundle["roas_p10"].predict(X),
        "roas_expected": model_bundle["roas_p50"].predict(X),
        "roas_upper": model_bundle["roas_p90"].predict(X)
    })

    # Recover multi-level granularity dimensions 
    output_df["marketing_channel"] = df_features.get("channel", "Aggregate Blended Portfolio")
    output_df["campaign_name"] = df_features.get("campaign_name", "Portfolio Baseline Pacing")

    insights, risks = [], []
    for _, row in output_df.iterrows():
        ins, rsk = evaluate_causal_signals(row)
        insights.append(ins)
        risks.append(rsk)
        
    output_df["ai_causal_explanation"] = insights
    output_df["operational_risk_factor"] = risks

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    output_df.to_csv(args.output, index=False)

    # --- PRESENTATION DASHBOARD TERMINAL PRINT ---
    print("\n" + "═"*85)
    print(" AIGNITION 3.0 — ENTERPRISE PROBABILISTIC FORECASTING INTERPRETER")
    print("═"*85)
    
    total_rev_low = output_df["revenue_lower"].sum()
    total_rev_med = output_df["revenue_expected"].sum()
    total_rev_high = output_df["revenue_upper"].sum()
    avg_roas_med = output_df["roas_expected"].mean()

    print(f"│ Target Metric     │ Lower Boundary (P10) │ Expected Midpoint (P50) │ Upper Boundary (P90) │")
    print(f"├───────────────────┼──────────────────────┼─────────────────────────┼──────────────────────┤")
    print(f"│ Gross Revenue     │ ₹{total_rev_low:-20,.2f} │ ₹{total_rev_med:-23,.2f} │ ₹{total_rev_high:-20,.2f} │")
    print(f"│ Blended Portfolio │ Summary Metric       │ {avg_roas_med:21.2f}x │ Summary Metric       │")
    print("═"*85)
    print(f"SUCCESS: Rich operational matrices successfully generated in {args.output}\n")

if __name__ == '__main__':
    main()