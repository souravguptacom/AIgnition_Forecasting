import joblib
import pandas as pd

model = joblib.load("pickle/model.pkl")

budget = float(input("Enter budget: "))

data = pd.DataFrame({
    "spend": [budget],
    "clicks": [budget * 0.08],
    "impressions": [budget * 2],
    "conversions": [budget * 0.005]
})

prediction = model.predict(data)

print(f"Expected Revenue: ₹{prediction[0]:.2f}")
print(f"Expected ROAS: {prediction[0]/budget:.2f}x")