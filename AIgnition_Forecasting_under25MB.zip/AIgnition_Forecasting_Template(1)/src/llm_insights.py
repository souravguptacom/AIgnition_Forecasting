def generate_insights(revenue, roas):
    insights = []

    if roas > 5:
        insights.append(
            "Campaign efficiency is strong. Consider increasing budget."
        )
    else:
        insights.append(
            "ROAS is below target. Review campaign optimization."
        )

    if revenue > 50000:
        insights.append(
            "Revenue forecast indicates healthy growth potential."
        )

    return insights


if __name__ == "__main__":
    revenue = float(input("Revenue Forecast: "))
    roas = float(input("ROAS Forecast: "))

    for item in generate_insights(revenue, roas):
        print("-", item)